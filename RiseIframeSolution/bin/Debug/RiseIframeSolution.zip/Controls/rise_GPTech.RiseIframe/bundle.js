/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./RiseIframe/index.ts"
/*!*****************************!*\
  !*** ./RiseIframe/index.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   RiseIframe: () => (/* binding */ RiseIframe)\n/* harmony export */ });\nclass RiseIframe {\n  constructor() {\n    this._currentUrl = \"\";\n    this._GPLastClickedPage = \"\";\n  }\n  init(context, notifyOutputChanged, state, container) {\n    var _a;\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container.style.width = \"100%\";\n    this._container.style.height = \"100%\";\n    this._iframe = document.createElement(\"iframe\");\n    this._iframe.style.cssText = \"width:100%;height:100%;border:none;\";\n    var url = (_a = context.parameters.template) === null || _a === void 0 ? void 0 : _a.raw;\n    if (url) {\n      this._currentUrl = url;\n      this._iframe.src = url;\n    }\n    this._container.appendChild(this._iframe);\n    this._onMessageBound = this.onMessageReceived.bind(this);\n    window.addEventListener(\"message\", this._onMessageBound);\n  }\n  updateView(context) {\n    var _a;\n    var url = (_a = context.parameters.template) === null || _a === void 0 ? void 0 : _a.raw;\n    if (url && url !== this._currentUrl) {\n      this._currentUrl = url;\n      this._iframe.src = url;\n    }\n  }\n  isFromOurIframe(source) {\n    var ours = this._iframe.contentWindow;\n    if (!source || !ours) return false;\n    var w = source;\n    for (var i = 0; i < 6; i++) {\n      if (w === ours) return true;\n      if (w.parent === w) break;\n      w = w.parent;\n    }\n    return false;\n  }\n  onMessageReceived(event) {\n    if (typeof event.data !== \"string\" || event.data.indexOf(\"|\") === -1) return;\n    if (!this.isFromOurIframe(event.source)) return;\n    if (!/^[\\w-]+\\|\\d+$/.test(event.data)) return;\n    this._GPLastClickedPage = event.data;\n    this._notifyOutputChanged();\n  }\n  getOutputs() {\n    return {\n      GP_lastClickedPage: this._GPLastClickedPage\n    };\n  }\n  destroy() {\n    window.removeEventListener(\"message\", this._onMessageBound);\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RiseIframe/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = {};
/******/ 	__webpack_modules__["./RiseIframe/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('GPTech.RiseIframe', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RiseIframe);
} else {
	var GPTech = GPTech || {};
	GPTech.RiseIframe = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RiseIframe;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}