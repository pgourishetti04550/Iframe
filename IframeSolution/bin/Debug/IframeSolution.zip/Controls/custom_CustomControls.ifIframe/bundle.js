/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ifIframe/index.ts"
/*!***************************!*\
  !*** ./ifIframe/index.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ifIframe: () => (/* binding */ ifIframe)\n/* harmony export */ });\nclass ifIframe {\n  constructor() {\n    // Empty constructor\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    // Create the iframe element\n    this._iframe = document.createElement(\"iframe\");\n    this._iframe.style.width = \"100%\";\n    this._iframe.style.height = \"100%\";\n    this._iframe.style.border = \"none\";\n    // Get the initial value from the template property\n    var initialUrl = context.parameters.template.raw || \"\";\n    if (initialUrl) {\n      this._iframe.src = initialUrl;\n    }\n    // Append the iframe to the canvas container\n    this._container.appendChild(this._iframe);\n  }\n  updateView(context) {\n    // Update the iframe source whenever the 'template' property changes in Canvas App\n    var updatedUrl = context.parameters.template.raw || \"\";\n    if (this._iframe && this._iframe.src !== updatedUrl) {\n      this._iframe.src = updatedUrl;\n    }\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // Cleanup when control is removed\n    if (this._iframe) {\n      this._iframe.remove();\n    }\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ifIframe/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ifIframe/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CustomControls.ifIframe', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ifIframe);
} else {
	var CustomControls = CustomControls || {};
	CustomControls.ifIframe = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ifIframe;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}